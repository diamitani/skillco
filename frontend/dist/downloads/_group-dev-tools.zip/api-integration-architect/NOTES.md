# Notes: api-integration-architect

- Source repo: diamitani/hermes-agent-skills-marketplace
- Source path: hermes-agent-productive/software-development/api-integration-architect/SKILL.md
- Raw URL: https://raw.githubusercontent.com/diamitani/hermes-agent-skills-marketplace/main/hermes-agent-productive/software-development/api-integration-architect/SKILL.md
- Index category: dev-tools
- Scan flagged duplicate_of: api-integration-architect
- Frontmatter: rewritten (source frontmatter replaced)
- Description: rewritten to LLM-agnostic house standard
- Placeholders found (0): none
- Broken references (0):
  - none
- Relative references downloaded (0):
  - none
- Aliases collapsed into this copy (1):
  - diamitani/hermes-agent-skills-marketplace / hermes-agent-business/software-development/api-integration-architect/SKILL.md
