# Notes: master-calendar

- Source repo: diamitani/hermes-agent-skills-marketplace
- Source path: hermes-agent-productive/productivity/master-calendar/SKILL.md
- Raw URL: https://raw.githubusercontent.com/diamitani/hermes-agent-skills-marketplace/main/hermes-agent-productive/productivity/master-calendar/SKILL.md
- Index category: ai-agents
- Scan flagged duplicate_of: master-calendar
- Frontmatter: rewritten (source frontmatter replaced)
- Description: rewritten to LLM-agnostic house standard
- Placeholders found (0): none
- Broken references (1):
  - `references/npao-orchestrator.md` — 404 / not found
- Relative references downloaded (0):
  - none
- Aliases collapsed into this copy (1):
  - diamitani/hermes-agent-skills-marketplace / hermes-agent-business/productivity/master-calendar/SKILL.md
