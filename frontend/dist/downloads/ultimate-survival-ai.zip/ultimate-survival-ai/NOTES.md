# Notes: ultimate-survival-ai

- Source repo: diamitani/hermes-agent-skills-marketplace
- Source path: hermes-agent-community/lifestyle/ultimate-survival-ai/SKILL.md
- Raw URL: https://raw.githubusercontent.com/diamitani/hermes-agent-skills-marketplace/main/hermes-agent-community/lifestyle/ultimate-survival-ai/SKILL.md
- Index category: ai-agents
- Frontmatter: rewritten (source frontmatter replaced)
- Description: rewritten to LLM-agnostic house standard
- Placeholders found (0): none
- Broken references (0):
  - none
- Relative references downloaded (0):
  - none
- Aliases collapsed into this copy (0):
  - none
